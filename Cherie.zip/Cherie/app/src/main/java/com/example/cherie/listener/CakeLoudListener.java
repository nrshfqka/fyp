package com.example.cherie.listener;

import com.example.cherie.model.CakeModel;

import java.util.List;

public interface CakeLoudListener {
    void onCakeLoadSuccess(List<CakeModel> cakeModelList);
    void onCakeLoadFailed(String message);
}
