package com.example.cherie.listener;

import com.example.cherie.model.CakeModel;

import java.util.List;

public interface CartLoadListener {
    void onCartLoadSuccess(List<CakeModel> cakeModelList);
    void onCartLoadFailed(String message);



}
