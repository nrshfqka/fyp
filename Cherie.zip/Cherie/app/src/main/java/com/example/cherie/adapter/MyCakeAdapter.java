package com.example.cherie.adapter;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cherie.R;
import com.example.cherie.model.CakeModel;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class MyCakeAdapter extends RecyclerView.Adapter<MyCakeAdapter.MyCakeViewHolder> {

    private Context context;
    private List<CakeModel> cakeModelList;

    public MyCakeAdapter(Context context, List<CakeModel> cakeModelList) {
        this.context = context;
        this.cakeModelList = cakeModelList;
    }

    @NonNull
    @Override
    public MyCakeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyCakeViewHolder(LayoutInflater.from(context).inflate(R.layout.layout_cake_item, parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyCakeViewHolder holder, int position) {
        Glide.with(context).load(cakeModelList.get(position).getImage()).into(holder.imageVeiw);
        holder.txt_price.setText(new StringBuilder("RM").append(cakeModelList.get(position).getPrice()));
        holder.txt_name.setText(new StringBuilder().append(cakeModelList.get(position).getName()));
    }

    @Override
    public int getItemCount() {
        return cakeModelList.size();
    }


    public class MyCakeViewHolder extends RecyclerView.ViewHolder{
        @BindView(R.id.imageVeiw)
        ImageView imageVeiw;
        @BindView(R.id.txt_Price)
        TextView txt_price;
        @BindView(R.id.txt_name)
        TextView txt_name;

        private Unbinder unbinder;
        public MyCakeViewHolder(@NonNull View itemView) {
            super(itemView);
            unbinder = ButterKnife.bind(this, itemView);

        }
    }

}
