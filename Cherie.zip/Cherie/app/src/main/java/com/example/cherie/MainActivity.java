package com.example.cherie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.RelativeLayout;

import com.example.cherie.adapter.MyCakeAdapter;
import com.example.cherie.listener.CakeLoudListener;
import com.example.cherie.listener.CartLoadListener;
import com.example.cherie.model.CakeModel;
import com.example.cherie.util.SpaceItemDecoration;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nex3z.notificationbadge.NotificationBadge;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements CakeLoudListener, CartLoadListener {
    @BindView(R.id.recycler_cake)
    RecyclerView recycler_cake;
    @BindView(R.id.mainLayout)
    RelativeLayout mainLayout;
    @BindView(R.id.badge)
    NotificationBadge badge;
    @BindView(R.id.btnCart)
    FrameLayout btnCart;

    CakeLoudListener cakeLoudListener;
    CartLoadListener cartLoadListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        loadCakeFromFirebase();
    }
    private void loadCakeFromFirebase(){
        List<CakeModel> cakeModels=new ArrayList<>();
        FirebaseDatabase.getInstance().getReference("Cake").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for(DataSnapshot cakeSnapshot: dataSnapshot.getChildren()){
                        CakeModel cakeModel= cakeSnapshot.getValue(CakeModel.class);
                        cakeModel.setKey(cakeSnapshot.getKey());
                        cakeModels.add(cakeModel);

                    }
                    cakeLoudListener.onCakeLoadSuccess(cakeModels);
                }
                else
                    cakeLoudListener.onCakeLoadFailed("Can't Find Cake");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                cakeLoudListener.onCakeLoadFailed(error.getMessage());
            }
        });
    }

    private void init(){
        ButterKnife.bind(this);
        cakeLoudListener=this;
        cartLoadListener=this;

        GridLayoutManager gridLayoutManager= new GridLayoutManager(this, 2);
        recycler_cake.setLayoutManager(gridLayoutManager);
        recycler_cake.addItemDecoration(new SpaceItemDecoration());

    }

    @Override
    public void onCakeLoadSuccess(List<CakeModel> cakeModelList) {

    }

    @Override
    public void onCakeLoadFailed(String message) {
        Snackbar.make(mainLayout,message,Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void onCartLoadSuccess(List<CakeModel> cakeModelList) {
        MyCakeAdapter adapter= new MyCakeAdapter(this,cakeModelList);
        recycler_cake.setAdapter(adapter);

    }

    @Override
    public void onCartLoadFailed(String message) {

    }
}
